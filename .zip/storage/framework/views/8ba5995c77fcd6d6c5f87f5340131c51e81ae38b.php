<nav class="navbar bg-light sticky-top">
  <div class="container-fluid">
    <ul class="navbar-nav sidebar vh-100">

      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('challenge1')); ?>">Challenge 1</a>
      </li>

    </ul>
  </div>
</nav>
<?php /**PATH L:\xampp\htdocs\projects\techvill\resources\views\layouts\sidebar.blade.php ENDPATH**/ ?>