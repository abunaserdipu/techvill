
<?php $__env->startSection('content'); ?>
  hello
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\projects\techvill\resources\views\pages\challenge2.blade.php ENDPATH**/ ?>