<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Techvill</a>
  </div>
</nav>
<?php /**PATH L:\xampp\htdocs\projects\techvill\resources\views\layouts\top_nav.blade.php ENDPATH**/ ?>