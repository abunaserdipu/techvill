
<?php $__env->startSection('content'); ?>
  <form action="<?php echo e(route('user.search')); ?>" method="get" class="py-5 text-center">
    <input type="search" name="q" id="user" placeholder="Search user">
    <button type="submit" class="btn btn-outline-success">Search</button>
  </form>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>UUID</th>
        <th>FirtName</th>
        <th>LastName</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $tech_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($tech_user->uuid); ?></td>
          <td><?php echo e($tech_user->first_name); ?></td>
          <td><?php echo e($tech_user->last_name); ?></td>
          <td><?php echo e($tech_user->email); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\projects\techvill\resources\views\pages\challenge1.blade.php ENDPATH**/ ?>