<nav class="navbar bg-light sticky-top">
  <div class="container-fluid">
    <ul class="navbar-nav sidebar vh-100">

      <li class="nav-item">
        <a class="nav-link" href="{{ route('challenge1') }}">Challenge 1</a>
      </li>

    </ul>
  </div>
</nav>
